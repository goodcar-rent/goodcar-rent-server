export const ACL_READ = 'read'
export const ACL_WRITE = 'write'

export const ACL_USER_ACLS = 'acl/user-acls'
export const ACL_USER_GROUP_ACLS = 'acl/user-group-acls'

export const ACL_ADMIN = 'admin'

export const ACL_INVITE = '/auth/invite'

export const ACL_ME = 'me'

export const ACL_USER_GROUPS = 'user-groups'

export const ACL_USERS = 'users'
